../objects/application/app_main.c.o: src/app_main.c \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/lib/gcc/arm-none-eabi/12.2.1/include/stdint.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/stdint.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/machine/_default_types.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/features.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/_newlib_version.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/_intsup.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/_stdint.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/stdlib.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/machine/ieeefp.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/_ansi.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/newlib.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/config.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/lib/gcc/arm-none-eabi/12.2.1/include/stddef.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/reent.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/_ansi.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/_types.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/machine/_types.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/lock.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/cdefs.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/machine/stdlib.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/string.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/string.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/types.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/_pthreadtypes.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/machine/types.h \
 ../nrf52_sdk/components/libraries/util/nordic_common.h \
 ../nrf52_sdk/modules/nrfx/mdk/nrf.h \
 ../nrf52_sdk/modules/nrfx/mdk/nrf52840.h \
 ../nrf52_sdk/components/toolchain/cmsis/include/core_cm4.h \
 ../nrf52_sdk/components/toolchain/cmsis/include/cmsis_version.h \
 ../nrf52_sdk/components/toolchain/cmsis/include/cmsis_compiler.h \
 ../nrf52_sdk/components/toolchain/cmsis/include/cmsis_gcc.h \
 ../nrf52_sdk/components/toolchain/cmsis/include/mpu_armv7.h \
 ../nrf52_sdk/modules/nrfx/mdk/system_nrf52840.h \
 ../nrf52_sdk/modules/nrfx/mdk/nrf52840_bitfields.h \
 ../nrf52_sdk/modules/nrfx/mdk/nrf51_to_nrf52840.h \
 ../nrf52_sdk/modules/nrfx/mdk/nrf52_to_nrf52840.h \
 ../nrf52_sdk/modules/nrfx/mdk/compiler_abstraction.h \
 ../nrf52_sdk/components/libraries/timer/app_timer.h src/sdk_config.h \
 src/app_config.h ../common/device_info.h \
 ../nrf52_sdk/components/libraries/util/app_error.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/stdio.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/lib/gcc/arm-none-eabi/12.2.1/include/stdarg.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/stdio.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/lib/gcc/arm-none-eabi/12.2.1/include/stdbool.h \
 ../nrf52_sdk/components/libraries/util/sdk_errors.h \
 ../nrf52_sdk/components/softdevice/s140/headers/nrf_error.h \
 ../nrf52_sdk/components/libraries/util/nordic_common.h \
 ../nrf52_sdk/components/libraries/util/app_error_weak.h \
 ../nrf52_sdk/components/libraries/util/app_util.h \
 ../nrf52_sdk/modules/nrfx/mdk/compiler_abstraction.h \
 ../nrf52_sdk/components/softdevice/s140/headers/nrf52/nrf_mbr.h \
 ../nrf52_sdk/components/softdevice/s140/headers/nrf_svc.h \
 ../nrf52_sdk/components/libraries/log/nrf_log_instance.h \
 ../nrf52_sdk/components/libraries/experimental_section_vars/nrf_section.h \
 ../nrf52_sdk/components/libraries/log/nrf_log_types.h \
 ../nrf52_sdk/components/libraries/sortlist/nrf_sortlist.h \
 ../nrf52_sdk/components/libraries/usbd/app_usbd.h \
 ../nrf52_sdk/integration/nrfx/legacy/nrf_drv_usbd.h \
 ../nrf52_sdk/modules/nrfx/nrfx.h \
 ../nrf52_sdk/integration/nrfx/nrfx_config.h \
 ../nrf52_sdk/modules/nrfx/drivers/nrfx_common.h \
 ../nrf52_sdk/modules/nrfx/mdk/nrf_peripherals.h \
 ../nrf52_sdk/modules/nrfx/mdk/nrf52840_peripherals.h \
 ../nrf52_sdk/integration/nrfx/nrfx_glue.h \
 ../nrf52_sdk/integration/nrfx/legacy/apply_old_config.h \
 ../nrf52_sdk/modules/nrfx/soc/nrfx_irqs.h \
 ../nrf52_sdk/modules/nrfx/soc/nrfx_irqs_nrf52840.h \
 ../nrf52_sdk/components/libraries/util/nrf_assert.h \
 ../nrf52_sdk/components/libraries/util/app_util_platform.h \
 ../nrf52_sdk/components/softdevice/s140/headers/nrf_soc.h \
 ../nrf52_sdk/components/softdevice/s140/headers/nrf_svc.h \
 ../nrf52_sdk/components/softdevice/s140/headers/nrf_error.h \
 ../nrf52_sdk/components/softdevice/s140/headers/nrf_error_soc.h \
 ../nrf52_sdk/components/softdevice/s140/headers/nrf_nvic.h \
 ../nrf52_sdk/components/libraries/util/nrf_assert.h \
 ../nrf52_sdk/components/libraries/util/app_error.h \
 ../nrf52_sdk/modules/nrfx/soc/nrfx_coredep.h \
 ../nrf52_sdk/modules/nrfx/soc/nrfx_atomic.h \
 ../nrf52_sdk/components/libraries/util/sdk_errors.h \
 ../nrf52_sdk/components/libraries/util/sdk_resources.h \
 ../nrf52_sdk/components/softdevice/s140/headers/nrf_sd_def.h \
 ../nrf52_sdk/components/softdevice/s140/headers/nrf_soc.h \
 ../nrf52_sdk/modules/nrfx/drivers/nrfx_errors.h \
 ../nrf52_sdk/modules/nrfx/drivers/include/nrfx_usbd.h \
 ../nrf52_sdk/modules/nrfx/hal/nrf_usbd.h \
 ../nrf52_sdk/integration/nrfx/legacy/nrf_drv_usbd_errata.h \
 ../nrf52_sdk/modules/nrfx/drivers/include/../src/nrfx_usbd_errata.h \
 ../nrf52_sdk/modules/nrfx/mdk/nrf_erratas.h \
 ../nrf52_sdk/modules/nrfx/mdk/nrf.h \
 ../nrf52_sdk/modules/nrfx/mdk/nrf51_erratas.h \
 ../nrf52_sdk/modules/nrfx/mdk/nrf52_erratas.h \
 ../nrf52_sdk/modules/nrfx/mdk/nrf53_erratas.h \
 ../nrf52_sdk/modules/nrfx/mdk/nrf91_erratas.h \
 ../nrf52_sdk/components/libraries/usbd/app_usbd_types.h \
 ../nrf52_sdk/components/libraries/usbd/app_usbd_request.h \
 ../nrf52_sdk/components/libraries/util/sdk_common.h \
 ../nrf52_sdk/components/libraries/util/sdk_os.h \
 ../nrf52_sdk/components/libraries/util/app_util.h \
 ../nrf52_sdk/components/libraries/util/sdk_macros.h \
 ../nrf52_sdk/components/libraries/usbd/app_usbd_descriptor.h \
 ../nrf52_sdk/components/libraries/usbd/app_usbd_langid.h \
 ../nrf52_sdk/components/libraries/usbd/app_usbd_class_base.h \
 ../nrf52_sdk/components/libraries/delay/nrf_delay.h \
 ../nrf52_sdk/integration/nrfx/legacy/nrf_drv_gpiote.h \
 ../nrf52_sdk/modules/nrfx/drivers/include/nrfx_gpiote.h \
 ../nrf52_sdk/modules/nrfx/hal/nrf_gpiote.h \
 ../nrf52_sdk/modules/nrfx/hal/nrf_gpio.h \
 ../nrf52_sdk/integration/nrfx/legacy/nrf_drv_rng.h \
 ../nrf52_sdk/modules/nrfx/drivers/include/nrfx_rng.h \
 ../nrf52_sdk/modules/nrfx/hal/nrf_rng.h src/rfid/nfctag/hf/nfc_mf1.h \
 src/rfid/nfctag/hf/nfc_14a.h src/rfid/nfctag/tag_emulation.h \
 src/rfid/nfctag/tag_base_type.h ../common/utils.h src/utils/netdata.h \
 ../nrf52_sdk/modules/nrfx/hal/nrf_power.h \
 ../nrf52_sdk/components/libraries/pwr_mgmt/nrf_pwr_mgmt.h \
 ../nrf52_sdk/components/libraries/experimental_section_vars/nrf_section_iter.h \
 ../nrf52_sdk/components/libraries/experimental_section_vars/nrf_section.h \
 ../nrf52_sdk/modules/nrfx/drivers/include/nrfx_nfct.h \
 ../nrf52_sdk/modules/nrfx/hal/nrf_nfct.h \
 ../nrf52_sdk/modules/nrfx/drivers/include/nrfx_power.h \
 ../nrf52_sdk/modules/nrfx/hal/nrf_power.h \
 ../nrf52_sdk/modules/nrfx/drivers/include/nrfx_power_clock.h \
 ../nrf52_sdk/integration/nrfx/legacy/nrf_drv_lpcomp.h \
 ../nrf52_sdk/modules/nrfx/drivers/include/nrfx_lpcomp.h \
 ../nrf52_sdk/modules/nrfx/hal/nrf_lpcomp.h \
 ../nrf52_sdk/components/ble/peer_manager/nrf_ble_lesc.h \
 ../nrf52_sdk/components/softdevice/s140/headers/ble.h \
 ../nrf52_sdk/components/softdevice/s140/headers/ble_err.h \
 ../nrf52_sdk/components/softdevice/s140/headers/ble_gap.h \
 ../nrf52_sdk/components/softdevice/s140/headers/ble_hci.h \
 ../nrf52_sdk/components/softdevice/s140/headers/ble_ranges.h \
 ../nrf52_sdk/components/softdevice/s140/headers/ble_types.h \
 ../nrf52_sdk/components/softdevice/s140/headers/ble_l2cap.h \
 ../nrf52_sdk/components/softdevice/s140/headers/ble_gatt.h \
 ../nrf52_sdk/components/softdevice/s140/headers/ble_gattc.h \
 ../nrf52_sdk/components/softdevice/s140/headers/ble_gatts.h \
 ../nrf52_sdk/components/libraries/log/nrf_log.h \
 ../nrf52_sdk/components/libraries/strerror/nrf_strerror.h \
 ../nrf52_sdk/components/libraries/log/src/nrf_log_internal.h \
 ../nrf52_sdk/components/libraries/log/nrf_log_types.h \
 ../nrf52_sdk/components/libraries/log/nrf_log_ctrl.h \
 ../nrf52_sdk/components/libraries/log/src/nrf_log_ctrl_internal.h \
 ../nrf52_sdk/components/libraries/log/nrf_log_backend_interface.h \
 ../nrf52_sdk/components/libraries/memobj/nrf_memobj.h \
 ../nrf52_sdk/components/libraries/balloc/nrf_balloc.h \
 ../nrf52_sdk/components/libraries/log/nrf_log_default_backends.h \
 src/app_cmd.h src/utils/dataframe.h src/ble_main.h \
 ../nrf52_sdk/components/ble/ble_services/ble_bas/ble_bas.h \
 ../nrf52_sdk/components/ble/common/ble_srv_common.h \
 ../nrf52_sdk/components/softdevice/s140/headers/ble_types.h \
 ../nrf52_sdk/components/softdevice/s140/headers/ble_gap.h \
 ../nrf52_sdk/components/softdevice/s140/headers/ble_gatt.h \
 ../nrf52_sdk/components/softdevice/common/nrf_sdh_ble.h \
 ../nrf52_sdk/components/softdevice/s140/headers/ble_gatts.h \
 ../nrf52_sdk/components/ble/ble_services/ble_nus/ble_nus.h \
 ../nrf52_sdk/components/ble/ble_link_ctx_manager/ble_link_ctx_manager.h \
 ../nrf52_sdk/components/ble/common/ble_conn_state.h \
 ../nrf52_sdk/components/libraries/atomic/nrf_atomic.h \
 ../nrf52_sdk/modules/nrfx/drivers/include/nrfx_saadc.h \
 ../nrf52_sdk/modules/nrfx/hal/nrf_saadc.h src/bsp/bsp_delay.h \
 src/bsp/bsp_time.h src/bsp/bsp_wdt.h src/utils/fds_util.h \
 ../nrf52_sdk/components/libraries/fds/fds.h src/rfid/hex_utils.h \
 src/rfid_main.h ../common/hw_connect.h \
 ../nrf52_sdk/modules/nrfx/hal/nrf_lpcomp.h \
 ../nrf52_sdk/modules/nrfx/hal/nrf_saadc.h ../common/device_info.h \
 src/rfid/nfctag/lf/lf_tag_em.h src/rfid_main.h \
 src/rfid/nfctag/hf/nfc_14a.h src/rfid/nfctag/hf/nfc_mf0_ntag.h \
 ../nrf52_sdk/modules/nrfx/hal/nrf_gpio.h \
 src/rfid/reader/lf/lf_reader_main.h src/app_status.h \
 src/rfid/reader/lf/lf_125khz_radio.h src/ble_main.h \
 ../nrf52_sdk/modules/nrfx/drivers/include/nrfx_pwm.h \
 ../nrf52_sdk/modules/nrfx/hal/nrf_pwm.h \
 src/rfid/reader/lf/lf_em4x05_data.h src/rfid/reader/lf/lf_reader_data.h \
 src/rfid/reader/hf/mf1_toolbox.h src/rfid/reader/hf/rc522.h \
 ../nrf52_sdk/components/toolchain/cmsis/include/cmsis_gcc.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/inttypes.h \
 src/utils/syssleep.h src/usb_main.h src/urat_esp/uart_esp.h \
 src/rgb_marquee.h ../nrf52_sdk/integration/nrfx/legacy/nrf_drv_pwm.h \
 src/rfid/nfctag/tag_persistence.h src/settings.h
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/lib/gcc/arm-none-eabi/12.2.1/include/stdint.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/stdint.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/machine/_default_types.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/features.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/_newlib_version.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/_intsup.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/_stdint.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/stdlib.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/machine/ieeefp.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/_ansi.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/newlib.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/config.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/lib/gcc/arm-none-eabi/12.2.1/include/stddef.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/reent.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/_ansi.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/_types.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/machine/_types.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/lock.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/cdefs.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/machine/stdlib.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/string.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/string.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/types.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/_pthreadtypes.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/machine/types.h:
../nrf52_sdk/components/libraries/util/nordic_common.h:
../nrf52_sdk/modules/nrfx/mdk/nrf.h:
../nrf52_sdk/modules/nrfx/mdk/nrf52840.h:
../nrf52_sdk/components/toolchain/cmsis/include/core_cm4.h:
../nrf52_sdk/components/toolchain/cmsis/include/cmsis_version.h:
../nrf52_sdk/components/toolchain/cmsis/include/cmsis_compiler.h:
../nrf52_sdk/components/toolchain/cmsis/include/cmsis_gcc.h:
../nrf52_sdk/components/toolchain/cmsis/include/mpu_armv7.h:
../nrf52_sdk/modules/nrfx/mdk/system_nrf52840.h:
../nrf52_sdk/modules/nrfx/mdk/nrf52840_bitfields.h:
../nrf52_sdk/modules/nrfx/mdk/nrf51_to_nrf52840.h:
../nrf52_sdk/modules/nrfx/mdk/nrf52_to_nrf52840.h:
../nrf52_sdk/modules/nrfx/mdk/compiler_abstraction.h:
../nrf52_sdk/components/libraries/timer/app_timer.h:
src/sdk_config.h:
src/app_config.h:
../common/device_info.h:
../nrf52_sdk/components/libraries/util/app_error.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/stdio.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/lib/gcc/arm-none-eabi/12.2.1/include/stdarg.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/stdio.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/lib/gcc/arm-none-eabi/12.2.1/include/stdbool.h:
../nrf52_sdk/components/libraries/util/sdk_errors.h:
../nrf52_sdk/components/softdevice/s140/headers/nrf_error.h:
../nrf52_sdk/components/libraries/util/nordic_common.h:
../nrf52_sdk/components/libraries/util/app_error_weak.h:
../nrf52_sdk/components/libraries/util/app_util.h:
../nrf52_sdk/modules/nrfx/mdk/compiler_abstraction.h:
../nrf52_sdk/components/softdevice/s140/headers/nrf52/nrf_mbr.h:
../nrf52_sdk/components/softdevice/s140/headers/nrf_svc.h:
../nrf52_sdk/components/libraries/log/nrf_log_instance.h:
../nrf52_sdk/components/libraries/experimental_section_vars/nrf_section.h:
../nrf52_sdk/components/libraries/log/nrf_log_types.h:
../nrf52_sdk/components/libraries/sortlist/nrf_sortlist.h:
../nrf52_sdk/components/libraries/usbd/app_usbd.h:
../nrf52_sdk/integration/nrfx/legacy/nrf_drv_usbd.h:
../nrf52_sdk/modules/nrfx/nrfx.h:
../nrf52_sdk/integration/nrfx/nrfx_config.h:
../nrf52_sdk/modules/nrfx/drivers/nrfx_common.h:
../nrf52_sdk/modules/nrfx/mdk/nrf_peripherals.h:
../nrf52_sdk/modules/nrfx/mdk/nrf52840_peripherals.h:
../nrf52_sdk/integration/nrfx/nrfx_glue.h:
../nrf52_sdk/integration/nrfx/legacy/apply_old_config.h:
../nrf52_sdk/modules/nrfx/soc/nrfx_irqs.h:
../nrf52_sdk/modules/nrfx/soc/nrfx_irqs_nrf52840.h:
../nrf52_sdk/components/libraries/util/nrf_assert.h:
../nrf52_sdk/components/libraries/util/app_util_platform.h:
../nrf52_sdk/components/softdevice/s140/headers/nrf_soc.h:
../nrf52_sdk/components/softdevice/s140/headers/nrf_svc.h:
../nrf52_sdk/components/softdevice/s140/headers/nrf_error.h:
../nrf52_sdk/components/softdevice/s140/headers/nrf_error_soc.h:
../nrf52_sdk/components/softdevice/s140/headers/nrf_nvic.h:
../nrf52_sdk/components/libraries/util/nrf_assert.h:
../nrf52_sdk/components/libraries/util/app_error.h:
../nrf52_sdk/modules/nrfx/soc/nrfx_coredep.h:
../nrf52_sdk/modules/nrfx/soc/nrfx_atomic.h:
../nrf52_sdk/components/libraries/util/sdk_errors.h:
../nrf52_sdk/components/libraries/util/sdk_resources.h:
../nrf52_sdk/components/softdevice/s140/headers/nrf_sd_def.h:
../nrf52_sdk/components/softdevice/s140/headers/nrf_soc.h:
../nrf52_sdk/modules/nrfx/drivers/nrfx_errors.h:
../nrf52_sdk/modules/nrfx/drivers/include/nrfx_usbd.h:
../nrf52_sdk/modules/nrfx/hal/nrf_usbd.h:
../nrf52_sdk/integration/nrfx/legacy/nrf_drv_usbd_errata.h:
../nrf52_sdk/modules/nrfx/drivers/include/../src/nrfx_usbd_errata.h:
../nrf52_sdk/modules/nrfx/mdk/nrf_erratas.h:
../nrf52_sdk/modules/nrfx/mdk/nrf.h:
../nrf52_sdk/modules/nrfx/mdk/nrf51_erratas.h:
../nrf52_sdk/modules/nrfx/mdk/nrf52_erratas.h:
../nrf52_sdk/modules/nrfx/mdk/nrf53_erratas.h:
../nrf52_sdk/modules/nrfx/mdk/nrf91_erratas.h:
../nrf52_sdk/components/libraries/usbd/app_usbd_types.h:
../nrf52_sdk/components/libraries/usbd/app_usbd_request.h:
../nrf52_sdk/components/libraries/util/sdk_common.h:
../nrf52_sdk/components/libraries/util/sdk_os.h:
../nrf52_sdk/components/libraries/util/app_util.h:
../nrf52_sdk/components/libraries/util/sdk_macros.h:
../nrf52_sdk/components/libraries/usbd/app_usbd_descriptor.h:
../nrf52_sdk/components/libraries/usbd/app_usbd_langid.h:
../nrf52_sdk/components/libraries/usbd/app_usbd_class_base.h:
../nrf52_sdk/components/libraries/delay/nrf_delay.h:
../nrf52_sdk/integration/nrfx/legacy/nrf_drv_gpiote.h:
../nrf52_sdk/modules/nrfx/drivers/include/nrfx_gpiote.h:
../nrf52_sdk/modules/nrfx/hal/nrf_gpiote.h:
../nrf52_sdk/modules/nrfx/hal/nrf_gpio.h:
../nrf52_sdk/integration/nrfx/legacy/nrf_drv_rng.h:
../nrf52_sdk/modules/nrfx/drivers/include/nrfx_rng.h:
../nrf52_sdk/modules/nrfx/hal/nrf_rng.h:
src/rfid/nfctag/hf/nfc_mf1.h:
src/rfid/nfctag/hf/nfc_14a.h:
src/rfid/nfctag/tag_emulation.h:
src/rfid/nfctag/tag_base_type.h:
../common/utils.h:
src/utils/netdata.h:
../nrf52_sdk/modules/nrfx/hal/nrf_power.h:
../nrf52_sdk/components/libraries/pwr_mgmt/nrf_pwr_mgmt.h:
../nrf52_sdk/components/libraries/experimental_section_vars/nrf_section_iter.h:
../nrf52_sdk/components/libraries/experimental_section_vars/nrf_section.h:
../nrf52_sdk/modules/nrfx/drivers/include/nrfx_nfct.h:
../nrf52_sdk/modules/nrfx/hal/nrf_nfct.h:
../nrf52_sdk/modules/nrfx/drivers/include/nrfx_power.h:
../nrf52_sdk/modules/nrfx/hal/nrf_power.h:
../nrf52_sdk/modules/nrfx/drivers/include/nrfx_power_clock.h:
../nrf52_sdk/integration/nrfx/legacy/nrf_drv_lpcomp.h:
../nrf52_sdk/modules/nrfx/drivers/include/nrfx_lpcomp.h:
../nrf52_sdk/modules/nrfx/hal/nrf_lpcomp.h:
../nrf52_sdk/components/ble/peer_manager/nrf_ble_lesc.h:
../nrf52_sdk/components/softdevice/s140/headers/ble.h:
../nrf52_sdk/components/softdevice/s140/headers/ble_err.h:
../nrf52_sdk/components/softdevice/s140/headers/ble_gap.h:
../nrf52_sdk/components/softdevice/s140/headers/ble_hci.h:
../nrf52_sdk/components/softdevice/s140/headers/ble_ranges.h:
../nrf52_sdk/components/softdevice/s140/headers/ble_types.h:
../nrf52_sdk/components/softdevice/s140/headers/ble_l2cap.h:
../nrf52_sdk/components/softdevice/s140/headers/ble_gatt.h:
../nrf52_sdk/components/softdevice/s140/headers/ble_gattc.h:
../nrf52_sdk/components/softdevice/s140/headers/ble_gatts.h:
../nrf52_sdk/components/libraries/log/nrf_log.h:
../nrf52_sdk/components/libraries/strerror/nrf_strerror.h:
../nrf52_sdk/components/libraries/log/src/nrf_log_internal.h:
../nrf52_sdk/components/libraries/log/nrf_log_types.h:
../nrf52_sdk/components/libraries/log/nrf_log_ctrl.h:
../nrf52_sdk/components/libraries/log/src/nrf_log_ctrl_internal.h:
../nrf52_sdk/components/libraries/log/nrf_log_backend_interface.h:
../nrf52_sdk/components/libraries/memobj/nrf_memobj.h:
../nrf52_sdk/components/libraries/balloc/nrf_balloc.h:
../nrf52_sdk/components/libraries/log/nrf_log_default_backends.h:
src/app_cmd.h:
src/utils/dataframe.h:
src/ble_main.h:
../nrf52_sdk/components/ble/ble_services/ble_bas/ble_bas.h:
../nrf52_sdk/components/ble/common/ble_srv_common.h:
../nrf52_sdk/components/softdevice/s140/headers/ble_types.h:
../nrf52_sdk/components/softdevice/s140/headers/ble_gap.h:
../nrf52_sdk/components/softdevice/s140/headers/ble_gatt.h:
../nrf52_sdk/components/softdevice/common/nrf_sdh_ble.h:
../nrf52_sdk/components/softdevice/s140/headers/ble_gatts.h:
../nrf52_sdk/components/ble/ble_services/ble_nus/ble_nus.h:
../nrf52_sdk/components/ble/ble_link_ctx_manager/ble_link_ctx_manager.h:
../nrf52_sdk/components/ble/common/ble_conn_state.h:
../nrf52_sdk/components/libraries/atomic/nrf_atomic.h:
../nrf52_sdk/modules/nrfx/drivers/include/nrfx_saadc.h:
../nrf52_sdk/modules/nrfx/hal/nrf_saadc.h:
src/bsp/bsp_delay.h:
src/bsp/bsp_time.h:
src/bsp/bsp_wdt.h:
src/utils/fds_util.h:
../nrf52_sdk/components/libraries/fds/fds.h:
src/rfid/hex_utils.h:
src/rfid_main.h:
../common/hw_connect.h:
../nrf52_sdk/modules/nrfx/hal/nrf_lpcomp.h:
../nrf52_sdk/modules/nrfx/hal/nrf_saadc.h:
../common/device_info.h:
src/rfid/nfctag/lf/lf_tag_em.h:
src/rfid_main.h:
src/rfid/nfctag/hf/nfc_14a.h:
src/rfid/nfctag/hf/nfc_mf0_ntag.h:
../nrf52_sdk/modules/nrfx/hal/nrf_gpio.h:
src/rfid/reader/lf/lf_reader_main.h:
src/app_status.h:
src/rfid/reader/lf/lf_125khz_radio.h:
src/ble_main.h:
../nrf52_sdk/modules/nrfx/drivers/include/nrfx_pwm.h:
../nrf52_sdk/modules/nrfx/hal/nrf_pwm.h:
src/rfid/reader/lf/lf_em4x05_data.h:
src/rfid/reader/lf/lf_reader_data.h:
src/rfid/reader/hf/mf1_toolbox.h:
src/rfid/reader/hf/rc522.h:
../nrf52_sdk/components/toolchain/cmsis/include/cmsis_gcc.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/inttypes.h:
src/utils/syssleep.h:
src/usb_main.h:
src/urat_esp/uart_esp.h:
src/rgb_marquee.h:
../nrf52_sdk/integration/nrfx/legacy/nrf_drv_pwm.h:
src/rfid/nfctag/tag_persistence.h:
src/settings.h:
