../objects/application/cc310_backend_eddsa.c.o: \
 ../nrf52_sdk/components/libraries/crypto/backend/cc310/cc310_backend_eddsa.c \
 src/sdk_config.h src/app_config.h ../common/device_info.h \
 ../nrf52_sdk/components/libraries/util/nordic_common.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/lib/gcc/arm-none-eabi/12.2.1/include/stdint.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/stdint.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/machine/_default_types.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/features.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/_newlib_version.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/_intsup.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/_stdint.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/lib/gcc/arm-none-eabi/12.2.1/include/stdbool.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/string.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/_ansi.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/newlib.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/config.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/machine/ieeefp.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/reent.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/_ansi.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/lib/gcc/arm-none-eabi/12.2.1/include/stddef.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/_types.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/machine/_types.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/lock.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/cdefs.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/string.h \
 ../nrf52_sdk/components/libraries/crypto/nrf_crypto_ecc.h \
 ../nrf52_sdk/components/libraries/crypto/nrf_crypto_error.h \
 ../nrf52_sdk/components/libraries/util/sdk_errors.h \
 ../nrf52_sdk/components/softdevice/s140/headers/nrf_error.h \
 ../nrf52_sdk/components/libraries/crypto/nrf_crypto_ecc_shared.h \
 ../nrf52_sdk/components/libraries/crypto/nrf_crypto_ecc_backend.h \
 ../nrf52_sdk/components/libraries/crypto/backend/cc310/cc310_backend_ecc.h \
 ../nrf52_sdk/components/libraries/crypto/nrf_crypto_ecc_shared.h \
 ../nrf52_sdk/external/nrf_cc310/include/crys_ecpki_kg.h \
 ../nrf52_sdk/external/nrf_cc310/include/crys_error.h \
 ../nrf52_sdk/external/nrf_cc310/include/ssi_pal_types.h \
 ../nrf52_sdk/external/nrf_cc310/include/ssi_pal_types_plat.h \
 ../nrf52_sdk/external/nrf_cc310/include/crys_rnd.h \
 ../nrf52_sdk/external/nrf_cc310/include/ssi_aes.h \
 ../nrf52_sdk/external/nrf_cc310/include/ssi_aes_error.h \
 ../nrf52_sdk/external/nrf_cc310/include/ssi_aes_defs.h \
 ../nrf52_sdk/external/nrf_cc310/include/crys_ecpki_types.h \
 ../nrf52_sdk/external/nrf_cc310/include/crys_hash.h \
 ../nrf52_sdk/external/nrf_cc310/include/crys_hash_defs.h \
 ../nrf52_sdk/external/nrf_cc310/include/crys_pka_defs_hw.h \
 ../nrf52_sdk/external/nrf_cc310/include/ssi_pka_hw_plat_defs.h \
 ../nrf52_sdk/external/nrf_cc310/include/ssi_pal_compiler.h \
 ../nrf52_sdk/external/nrf_cc310/include/crys_ec_mont_api.h \
 ../nrf52_sdk/external/nrf_cc310/include/crys_ec_edw_api.h \
 ../nrf52_sdk/components/libraries/crypto/backend/cc310_bl/cc310_bl_backend_ecc.h \
 ../nrf52_sdk/components/libraries/crypto/backend/mbedtls/mbedtls_backend_ecc.h \
 ../nrf52_sdk/components/libraries/crypto/backend/oberon/oberon_backend_ecc.h \
 ../nrf52_sdk/components/libraries/crypto/backend/micro_ecc/micro_ecc_backend_ecc.h \
 ../nrf52_sdk/components/libraries/crypto/backend/optiga/optiga_backend_ecc.h \
 ../nrf52_sdk/components/libraries/crypto/nrf_crypto_rng.h \
 ../nrf52_sdk/components/libraries/util/sdk_common.h \
 ../nrf52_sdk/components/libraries/util/nordic_common.h \
 ../nrf52_sdk/modules/nrfx/mdk/compiler_abstraction.h \
 ../nrf52_sdk/components/libraries/util/sdk_os.h \
 ../nrf52_sdk/components/libraries/util/sdk_errors.h \
 ../nrf52_sdk/components/libraries/util/app_util.h \
 ../nrf52_sdk/modules/nrfx/mdk/nrf.h \
 ../nrf52_sdk/modules/nrfx/mdk/nrf52840.h \
 ../nrf52_sdk/components/toolchain/cmsis/include/core_cm4.h \
 ../nrf52_sdk/components/toolchain/cmsis/include/cmsis_version.h \
 ../nrf52_sdk/components/toolchain/cmsis/include/cmsis_compiler.h \
 ../nrf52_sdk/components/toolchain/cmsis/include/cmsis_gcc.h \
 ../nrf52_sdk/components/toolchain/cmsis/include/mpu_armv7.h \
 ../nrf52_sdk/modules/nrfx/mdk/system_nrf52840.h \
 ../nrf52_sdk/modules/nrfx/mdk/nrf52840_bitfields.h \
 ../nrf52_sdk/modules/nrfx/mdk/nrf51_to_nrf52840.h \
 ../nrf52_sdk/modules/nrfx/mdk/nrf52_to_nrf52840.h \
 ../nrf52_sdk/modules/nrfx/mdk/compiler_abstraction.h \
 ../nrf52_sdk/components/softdevice/s140/headers/nrf52/nrf_mbr.h \
 ../nrf52_sdk/components/softdevice/s140/headers/nrf_svc.h \
 ../nrf52_sdk/components/libraries/util/sdk_macros.h \
 ../nrf52_sdk/components/libraries/util/nrf_assert.h \
 ../nrf52_sdk/components/libraries/crypto/nrf_crypto_rng_shared.h \
 ../nrf52_sdk/components/libraries/crypto/nrf_crypto_rng_backend.h \
 ../nrf52_sdk/components/libraries/crypto/backend/cc310/cc310_backend_rng.h \
 ../nrf52_sdk/components/libraries/crypto/nrf_crypto_rng_shared.h \
 ../nrf52_sdk/external/nrf_cc310/include/crys_rnd.h \
 ../nrf52_sdk/components/libraries/crypto/backend/nrf_hw/nrf_hw_backend_rng.h \
 ../nrf52_sdk/components/libraries/crypto/backend/nrf_hw/nrf_hw_backend_rng_mbedtls.h \
 ../nrf52_sdk/components/libraries/crypto/backend/optiga/optiga_backend_rng.h \
 ../nrf52_sdk/components/libraries/crypto/nrf_crypto_eddsa.h \
 ../nrf52_sdk/components/libraries/crypto/nrf_crypto_ecc.h \
 ../nrf52_sdk/components/libraries/crypto/nrf_crypto_eddsa_shared.h \
 ../nrf52_sdk/components/libraries/crypto/nrf_crypto_eddsa_backend.h \
 ../nrf52_sdk/components/libraries/crypto/nrf_crypto_ecdsa_shared.h \
 ../nrf52_sdk/components/libraries/crypto/backend/cc310/cc310_backend_eddsa.h \
 ../nrf52_sdk/components/libraries/crypto/nrf_crypto_eddsa_shared.h \
 ../nrf52_sdk/components/libraries/crypto/backend/oberon/oberon_backend_eddsa.h \
 ../nrf52_sdk/components/libraries/crypto/backend/cc310/cc310_backend_ecc.h \
 ../nrf52_sdk/components/libraries/crypto/backend/cc310/cc310_backend_shared.h \
 ../nrf52_sdk/components/libraries/crypto/backend/cc310/cc310_backend_mutex.h \
 ../nrf52_sdk/components/libraries/mutex/nrf_mtx.h \
 ../nrf52_sdk/components/libraries/atomic/nrf_atomic.h \
 ../nrf52_sdk/components/libraries/util/nrf_assert.h \
 ../nrf52_sdk/external/nrf_cc310/include/crys_ec_mont_edw_error.h
src/sdk_config.h:
src/app_config.h:
../common/device_info.h:
../nrf52_sdk/components/libraries/util/nordic_common.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/lib/gcc/arm-none-eabi/12.2.1/include/stdint.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/stdint.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/machine/_default_types.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/features.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/_newlib_version.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/_intsup.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/_stdint.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/lib/gcc/arm-none-eabi/12.2.1/include/stdbool.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/string.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/_ansi.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/newlib.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/config.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/machine/ieeefp.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/reent.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/_ansi.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/lib/gcc/arm-none-eabi/12.2.1/include/stddef.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/_types.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/machine/_types.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/lock.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/cdefs.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/string.h:
../nrf52_sdk/components/libraries/crypto/nrf_crypto_ecc.h:
../nrf52_sdk/components/libraries/crypto/nrf_crypto_error.h:
../nrf52_sdk/components/libraries/util/sdk_errors.h:
../nrf52_sdk/components/softdevice/s140/headers/nrf_error.h:
../nrf52_sdk/components/libraries/crypto/nrf_crypto_ecc_shared.h:
../nrf52_sdk/components/libraries/crypto/nrf_crypto_ecc_backend.h:
../nrf52_sdk/components/libraries/crypto/backend/cc310/cc310_backend_ecc.h:
../nrf52_sdk/components/libraries/crypto/nrf_crypto_ecc_shared.h:
../nrf52_sdk/external/nrf_cc310/include/crys_ecpki_kg.h:
../nrf52_sdk/external/nrf_cc310/include/crys_error.h:
../nrf52_sdk/external/nrf_cc310/include/ssi_pal_types.h:
../nrf52_sdk/external/nrf_cc310/include/ssi_pal_types_plat.h:
../nrf52_sdk/external/nrf_cc310/include/crys_rnd.h:
../nrf52_sdk/external/nrf_cc310/include/ssi_aes.h:
../nrf52_sdk/external/nrf_cc310/include/ssi_aes_error.h:
../nrf52_sdk/external/nrf_cc310/include/ssi_aes_defs.h:
../nrf52_sdk/external/nrf_cc310/include/crys_ecpki_types.h:
../nrf52_sdk/external/nrf_cc310/include/crys_hash.h:
../nrf52_sdk/external/nrf_cc310/include/crys_hash_defs.h:
../nrf52_sdk/external/nrf_cc310/include/crys_pka_defs_hw.h:
../nrf52_sdk/external/nrf_cc310/include/ssi_pka_hw_plat_defs.h:
../nrf52_sdk/external/nrf_cc310/include/ssi_pal_compiler.h:
../nrf52_sdk/external/nrf_cc310/include/crys_ec_mont_api.h:
../nrf52_sdk/external/nrf_cc310/include/crys_ec_edw_api.h:
../nrf52_sdk/components/libraries/crypto/backend/cc310_bl/cc310_bl_backend_ecc.h:
../nrf52_sdk/components/libraries/crypto/backend/mbedtls/mbedtls_backend_ecc.h:
../nrf52_sdk/components/libraries/crypto/backend/oberon/oberon_backend_ecc.h:
../nrf52_sdk/components/libraries/crypto/backend/micro_ecc/micro_ecc_backend_ecc.h:
../nrf52_sdk/components/libraries/crypto/backend/optiga/optiga_backend_ecc.h:
../nrf52_sdk/components/libraries/crypto/nrf_crypto_rng.h:
../nrf52_sdk/components/libraries/util/sdk_common.h:
../nrf52_sdk/components/libraries/util/nordic_common.h:
../nrf52_sdk/modules/nrfx/mdk/compiler_abstraction.h:
../nrf52_sdk/components/libraries/util/sdk_os.h:
../nrf52_sdk/components/libraries/util/sdk_errors.h:
../nrf52_sdk/components/libraries/util/app_util.h:
../nrf52_sdk/modules/nrfx/mdk/nrf.h:
../nrf52_sdk/modules/nrfx/mdk/nrf52840.h:
../nrf52_sdk/components/toolchain/cmsis/include/core_cm4.h:
../nrf52_sdk/components/toolchain/cmsis/include/cmsis_version.h:
../nrf52_sdk/components/toolchain/cmsis/include/cmsis_compiler.h:
../nrf52_sdk/components/toolchain/cmsis/include/cmsis_gcc.h:
../nrf52_sdk/components/toolchain/cmsis/include/mpu_armv7.h:
../nrf52_sdk/modules/nrfx/mdk/system_nrf52840.h:
../nrf52_sdk/modules/nrfx/mdk/nrf52840_bitfields.h:
../nrf52_sdk/modules/nrfx/mdk/nrf51_to_nrf52840.h:
../nrf52_sdk/modules/nrfx/mdk/nrf52_to_nrf52840.h:
../nrf52_sdk/modules/nrfx/mdk/compiler_abstraction.h:
../nrf52_sdk/components/softdevice/s140/headers/nrf52/nrf_mbr.h:
../nrf52_sdk/components/softdevice/s140/headers/nrf_svc.h:
../nrf52_sdk/components/libraries/util/sdk_macros.h:
../nrf52_sdk/components/libraries/util/nrf_assert.h:
../nrf52_sdk/components/libraries/crypto/nrf_crypto_rng_shared.h:
../nrf52_sdk/components/libraries/crypto/nrf_crypto_rng_backend.h:
../nrf52_sdk/components/libraries/crypto/backend/cc310/cc310_backend_rng.h:
../nrf52_sdk/components/libraries/crypto/nrf_crypto_rng_shared.h:
../nrf52_sdk/external/nrf_cc310/include/crys_rnd.h:
../nrf52_sdk/components/libraries/crypto/backend/nrf_hw/nrf_hw_backend_rng.h:
../nrf52_sdk/components/libraries/crypto/backend/nrf_hw/nrf_hw_backend_rng_mbedtls.h:
../nrf52_sdk/components/libraries/crypto/backend/optiga/optiga_backend_rng.h:
../nrf52_sdk/components/libraries/crypto/nrf_crypto_eddsa.h:
../nrf52_sdk/components/libraries/crypto/nrf_crypto_ecc.h:
../nrf52_sdk/components/libraries/crypto/nrf_crypto_eddsa_shared.h:
../nrf52_sdk/components/libraries/crypto/nrf_crypto_eddsa_backend.h:
../nrf52_sdk/components/libraries/crypto/nrf_crypto_ecdsa_shared.h:
../nrf52_sdk/components/libraries/crypto/backend/cc310/cc310_backend_eddsa.h:
../nrf52_sdk/components/libraries/crypto/nrf_crypto_eddsa_shared.h:
../nrf52_sdk/components/libraries/crypto/backend/oberon/oberon_backend_eddsa.h:
../nrf52_sdk/components/libraries/crypto/backend/cc310/cc310_backend_ecc.h:
../nrf52_sdk/components/libraries/crypto/backend/cc310/cc310_backend_shared.h:
../nrf52_sdk/components/libraries/crypto/backend/cc310/cc310_backend_mutex.h:
../nrf52_sdk/components/libraries/mutex/nrf_mtx.h:
../nrf52_sdk/components/libraries/atomic/nrf_atomic.h:
../nrf52_sdk/components/libraries/util/nrf_assert.h:
../nrf52_sdk/external/nrf_cc310/include/crys_ec_mont_edw_error.h:
