../objects/application/oberon_backend_chacha_poly_aead.c.o: \
 ../nrf52_sdk/components/libraries/crypto/backend/oberon/oberon_backend_chacha_poly_aead.c \
 ../nrf52_sdk/components/libraries/util/sdk_common.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/lib/gcc/arm-none-eabi/12.2.1/include/stdint.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/stdint.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/machine/_default_types.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/features.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/_newlib_version.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/_intsup.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/_stdint.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/lib/gcc/arm-none-eabi/12.2.1/include/stdbool.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/string.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/_ansi.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/newlib.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/config.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/machine/ieeefp.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/reent.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/_ansi.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/lib/gcc/arm-none-eabi/12.2.1/include/stddef.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/_types.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/machine/_types.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/lock.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/cdefs.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/string.h \
 src/sdk_config.h src/app_config.h ../common/device_info.h \
 ../nrf52_sdk/components/libraries/util/nordic_common.h \
 ../nrf52_sdk/modules/nrfx/mdk/compiler_abstraction.h \
 ../nrf52_sdk/components/libraries/util/sdk_os.h \
 ../nrf52_sdk/components/libraries/util/sdk_errors.h \
 ../nrf52_sdk/components/softdevice/s140/headers/nrf_error.h \
 ../nrf52_sdk/components/libraries/util/app_util.h \
 ../nrf52_sdk/modules/nrfx/mdk/nrf.h \
 ../nrf52_sdk/modules/nrfx/mdk/nrf52840.h \
 ../nrf52_sdk/components/toolchain/cmsis/include/core_cm4.h \
 ../nrf52_sdk/components/toolchain/cmsis/include/cmsis_version.h \
 ../nrf52_sdk/components/toolchain/cmsis/include/cmsis_compiler.h \
 ../nrf52_sdk/components/toolchain/cmsis/include/cmsis_gcc.h \
 ../nrf52_sdk/components/toolchain/cmsis/include/mpu_armv7.h \
 ../nrf52_sdk/modules/nrfx/mdk/system_nrf52840.h \
 ../nrf52_sdk/modules/nrfx/mdk/nrf52840_bitfields.h \
 ../nrf52_sdk/modules/nrfx/mdk/nrf51_to_nrf52840.h \
 ../nrf52_sdk/modules/nrfx/mdk/nrf52_to_nrf52840.h \
 ../nrf52_sdk/modules/nrfx/mdk/compiler_abstraction.h \
 ../nrf52_sdk/components/softdevice/s140/headers/nrf52/nrf_mbr.h \
 ../nrf52_sdk/components/softdevice/s140/headers/nrf_svc.h \
 ../nrf52_sdk/components/libraries/util/sdk_macros.h \
 ../nrf52_sdk/components/libraries/util/nrf_assert.h \
 ../nrf52_sdk/components/libraries/crypto/backend/oberon/oberon_backend_chacha_poly_aead.h
../nrf52_sdk/components/libraries/util/sdk_common.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/lib/gcc/arm-none-eabi/12.2.1/include/stdint.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/stdint.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/machine/_default_types.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/features.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/_newlib_version.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/_intsup.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/_stdint.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/lib/gcc/arm-none-eabi/12.2.1/include/stdbool.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/string.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/_ansi.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/newlib.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/config.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/machine/ieeefp.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/reent.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/_ansi.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/lib/gcc/arm-none-eabi/12.2.1/include/stddef.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/_types.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/machine/_types.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/lock.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/cdefs.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/string.h:
src/sdk_config.h:
src/app_config.h:
../common/device_info.h:
../nrf52_sdk/components/libraries/util/nordic_common.h:
../nrf52_sdk/modules/nrfx/mdk/compiler_abstraction.h:
../nrf52_sdk/components/libraries/util/sdk_os.h:
../nrf52_sdk/components/libraries/util/sdk_errors.h:
../nrf52_sdk/components/softdevice/s140/headers/nrf_error.h:
../nrf52_sdk/components/libraries/util/app_util.h:
../nrf52_sdk/modules/nrfx/mdk/nrf.h:
../nrf52_sdk/modules/nrfx/mdk/nrf52840.h:
../nrf52_sdk/components/toolchain/cmsis/include/core_cm4.h:
../nrf52_sdk/components/toolchain/cmsis/include/cmsis_version.h:
../nrf52_sdk/components/toolchain/cmsis/include/cmsis_compiler.h:
../nrf52_sdk/components/toolchain/cmsis/include/cmsis_gcc.h:
../nrf52_sdk/components/toolchain/cmsis/include/mpu_armv7.h:
../nrf52_sdk/modules/nrfx/mdk/system_nrf52840.h:
../nrf52_sdk/modules/nrfx/mdk/nrf52840_bitfields.h:
../nrf52_sdk/modules/nrfx/mdk/nrf51_to_nrf52840.h:
../nrf52_sdk/modules/nrfx/mdk/nrf52_to_nrf52840.h:
../nrf52_sdk/modules/nrfx/mdk/compiler_abstraction.h:
../nrf52_sdk/components/softdevice/s140/headers/nrf52/nrf_mbr.h:
../nrf52_sdk/components/softdevice/s140/headers/nrf_svc.h:
../nrf52_sdk/components/libraries/util/sdk_macros.h:
../nrf52_sdk/components/libraries/util/nrf_assert.h:
../nrf52_sdk/components/libraries/crypto/backend/oberon/oberon_backend_chacha_poly_aead.h:
