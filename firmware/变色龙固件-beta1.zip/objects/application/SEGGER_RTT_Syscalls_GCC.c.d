../objects/application/SEGGER_RTT_Syscalls_GCC.c.o: \
 ../nrf52_sdk/external/segger_rtt/SEGGER_RTT_Syscalls_GCC.c \
 src/sdk_config.h src/app_config.h ../common/device_info.h
src/sdk_config.h:
src/app_config.h:
../common/device_info.h:
