../objects/application/oberon_backend_ecc.c.o: \
 ../nrf52_sdk/components/libraries/crypto/backend/oberon/oberon_backend_ecc.c \
 src/sdk_config.h src/app_config.h ../common/device_info.h \
 ../nrf52_sdk/components/libraries/util/nordic_common.h
src/sdk_config.h:
src/app_config.h:
../common/device_info.h:
../nrf52_sdk/components/libraries/util/nordic_common.h:
