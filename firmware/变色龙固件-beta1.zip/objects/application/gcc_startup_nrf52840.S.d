../objects/application/gcc_startup_nrf52840.S.o: \
 ../nrf52_sdk/modules/nrfx/mdk/gcc_startup_nrf52840.S
