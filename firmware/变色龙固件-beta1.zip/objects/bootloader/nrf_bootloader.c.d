../objects/bootloader/nrf_bootloader.c.o: \
 ../nrf52_sdk/components/libraries/bootloader/nrf_bootloader.c \
 ../nrf52_sdk/components/libraries/bootloader/nrf_bootloader.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/lib/gcc/arm-none-eabi/12.2.1/include/stdint.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/stdint.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/machine/_default_types.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/features.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/_newlib_version.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/_intsup.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/_stdint.h \
 ../nrf52_sdk/components/libraries/bootloader/dfu/nrf_dfu.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/lib/gcc/arm-none-eabi/12.2.1/include/stdbool.h \
 ../nrf52_sdk/components/libraries/bootloader/dfu/nrf_dfu_types.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/lib/gcc/arm-none-eabi/12.2.1/include/stddef.h \
 ../nrf52_sdk/components/libraries/util/sdk_common.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/string.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/_ansi.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/newlib.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/config.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/machine/ieeefp.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/reent.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/_ansi.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/_types.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/machine/_types.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/lock.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/cdefs.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/string.h \
 src/sdk_config.h src/app_config.h ../common/device_info.h \
 ../nrf52_sdk/components/libraries/util/nordic_common.h \
 ../nrf52_sdk/modules/nrfx/mdk/compiler_abstraction.h \
 ../nrf52_sdk/components/libraries/util/sdk_os.h \
 ../nrf52_sdk/components/libraries/util/sdk_errors.h \
 ../nrf52_sdk/components/softdevice/s140/headers/nrf_error.h \
 ../nrf52_sdk/components/libraries/util/app_util.h \
 ../nrf52_sdk/modules/nrfx/mdk/nrf.h \
 ../nrf52_sdk/modules/nrfx/mdk/nrf52840.h \
 ../nrf52_sdk/components/toolchain/cmsis/include/core_cm4.h \
 ../nrf52_sdk/components/toolchain/cmsis/include/cmsis_version.h \
 ../nrf52_sdk/components/toolchain/cmsis/include/cmsis_compiler.h \
 ../nrf52_sdk/components/toolchain/cmsis/include/cmsis_gcc.h \
 ../nrf52_sdk/components/toolchain/cmsis/include/mpu_armv7.h \
 ../nrf52_sdk/modules/nrfx/mdk/system_nrf52840.h \
 ../nrf52_sdk/modules/nrfx/mdk/nrf52840_bitfields.h \
 ../nrf52_sdk/modules/nrfx/mdk/nrf51_to_nrf52840.h \
 ../nrf52_sdk/modules/nrfx/mdk/nrf52_to_nrf52840.h \
 ../nrf52_sdk/modules/nrfx/mdk/compiler_abstraction.h \
 ../nrf52_sdk/components/softdevice/s140/headers/nrf52/nrf_mbr.h \
 ../nrf52_sdk/components/softdevice/s140/headers/nrf_svc.h \
 ../nrf52_sdk/components/libraries/util/sdk_macros.h \
 ../nrf52_sdk/components/libraries/util/nrf_assert.h \
 ../nrf52_sdk/components/libraries/util/app_util_platform.h \
 ../nrf52_sdk/components/softdevice/s140/headers/nrf_soc.h \
 ../nrf52_sdk/components/softdevice/s140/headers/nrf_svc.h \
 ../nrf52_sdk/components/softdevice/s140/headers/nrf_error.h \
 ../nrf52_sdk/components/softdevice/s140/headers/nrf_error_soc.h \
 ../nrf52_sdk/components/softdevice/s140/headers/nrf_nvic.h \
 ../nrf52_sdk/components/libraries/util/app_error.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/stdio.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/lib/gcc/arm-none-eabi/12.2.1/include/stdarg.h \
 /usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/stdio.h \
 ../nrf52_sdk/components/libraries/util/app_error_weak.h \
 ../nrf52_sdk/components/softdevice/s140/headers/ble_gap.h \
 ../nrf52_sdk/components/softdevice/s140/headers/ble_hci.h \
 ../nrf52_sdk/components/softdevice/s140/headers/ble_ranges.h \
 ../nrf52_sdk/components/softdevice/s140/headers/ble_types.h \
 ../nrf52_sdk/components/softdevice/s140/headers/ble_err.h \
 ../nrf52_sdk/components/libraries/bootloader/dfu/nrf_dfu_req_handler.h \
 ../nrf52_sdk/components/libraries/bootloader/dfu/nrf_dfu_flash.h \
 ../nrf52_sdk/components/libraries/util/sdk_errors.h \
 ../nrf52_sdk/modules/nrfx/hal/nrf_power.h \
 ../nrf52_sdk/modules/nrfx/nrfx.h \
 ../nrf52_sdk/integration/nrfx/nrfx_config.h \
 ../nrf52_sdk/modules/nrfx/drivers/nrfx_common.h \
 ../nrf52_sdk/modules/nrfx/mdk/nrf_peripherals.h \
 ../nrf52_sdk/modules/nrfx/mdk/nrf52840_peripherals.h \
 ../nrf52_sdk/integration/nrfx/nrfx_glue.h \
 ../nrf52_sdk/integration/nrfx/legacy/apply_old_config.h \
 ../nrf52_sdk/modules/nrfx/soc/nrfx_irqs.h \
 ../nrf52_sdk/modules/nrfx/soc/nrfx_irqs_nrf52840.h \
 ../nrf52_sdk/components/libraries/util/nrf_assert.h \
 ../nrf52_sdk/components/libraries/util/app_util.h \
 ../nrf52_sdk/components/libraries/util/nordic_common.h \
 ../nrf52_sdk/modules/nrfx/soc/nrfx_coredep.h \
 ../nrf52_sdk/modules/nrfx/soc/nrfx_atomic.h \
 ../nrf52_sdk/components/libraries/util/sdk_resources.h \
 ../nrf52_sdk/components/softdevice/s140/headers/nrf_sd_def.h \
 ../nrf52_sdk/components/softdevice/s140/headers/nrf_soc.h \
 ../nrf52_sdk/modules/nrfx/drivers/nrfx_errors.h \
 ../nrf52_sdk/modules/nrfx/drivers/include/nrfx_power.h \
 ../nrf52_sdk/modules/nrfx/hal/nrf_power.h \
 ../nrf52_sdk/modules/nrfx/drivers/include/nrfx_power_clock.h \
 ../nrf52_sdk/components/libraries/delay/nrf_delay.h \
 ../nrf52_sdk/components/libraries/log/nrf_log.h \
 ../nrf52_sdk/components/libraries/experimental_section_vars/nrf_section.h \
 ../nrf52_sdk/components/libraries/log/src/nrf_log_internal.h \
 ../nrf52_sdk/components/libraries/log/nrf_log_instance.h \
 ../nrf52_sdk/components/libraries/log/nrf_log_types.h \
 ../nrf52_sdk/components/libraries/log/nrf_log_types.h \
 ../nrf52_sdk/components/libraries/log/nrf_log_ctrl.h \
 ../nrf52_sdk/components/libraries/log/src/nrf_log_ctrl_internal.h \
 ../nrf52_sdk/components/libraries/log/nrf_log_backend_interface.h \
 ../nrf52_sdk/components/libraries/bootloader/dfu/nrf_dfu_settings.h \
 ../nrf52_sdk/components/libraries/bootloader/dfu/nrf_dfu_utils.h \
 ../nrf52_sdk/components/libraries/bootloader/nrf_bootloader_wdt.h \
 ../nrf52_sdk/components/libraries/bootloader/nrf_bootloader_info.h \
 ../nrf52_sdk/components/softdevice/s140/headers/nrf_sdm.h \
 ../nrf52_sdk/components/softdevice/s140/headers/nrf_error_sdm.h \
 ../nrf52_sdk/components/libraries/bootloader/nrf_bootloader_app_start.h \
 ../nrf52_sdk/components/libraries/bootloader/nrf_bootloader_fw_activation.h \
 ../nrf52_sdk/components/libraries/bootloader/nrf_bootloader_dfu_timers.h \
 ../nrf52_sdk/components/libraries/scheduler/app_scheduler.h \
 ../nrf52_sdk/components/libraries/util/app_error.h \
 ../nrf52_sdk/components/libraries/bootloader/dfu/nrf_dfu_validation.h \
 ../nrf52_sdk/components/libraries/bootloader/dfu/dfu-cc.pb.h \
 ../nrf52_sdk/external/nano-pb/pb.h \
 ../nrf52_sdk/components/libraries/bootloader/dfu/nrf_dfu_handling_error.h \
 ../nrf52_sdk/modules/nrfx/hal/nrf_gpio.h ../common/hw_connect.h \
 ../nrf52_sdk/modules/nrfx/hal/nrf_lpcomp.h \
 ../nrf52_sdk/modules/nrfx/hal/nrf_saadc.h ../common/device_info.h
../nrf52_sdk/components/libraries/bootloader/nrf_bootloader.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/lib/gcc/arm-none-eabi/12.2.1/include/stdint.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/stdint.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/machine/_default_types.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/features.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/_newlib_version.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/_intsup.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/_stdint.h:
../nrf52_sdk/components/libraries/bootloader/dfu/nrf_dfu.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/lib/gcc/arm-none-eabi/12.2.1/include/stdbool.h:
../nrf52_sdk/components/libraries/bootloader/dfu/nrf_dfu_types.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/lib/gcc/arm-none-eabi/12.2.1/include/stddef.h:
../nrf52_sdk/components/libraries/util/sdk_common.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/string.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/_ansi.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/newlib.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/config.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/machine/ieeefp.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/reent.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/_ansi.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/_types.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/machine/_types.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/lock.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/cdefs.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/string.h:
src/sdk_config.h:
src/app_config.h:
../common/device_info.h:
../nrf52_sdk/components/libraries/util/nordic_common.h:
../nrf52_sdk/modules/nrfx/mdk/compiler_abstraction.h:
../nrf52_sdk/components/libraries/util/sdk_os.h:
../nrf52_sdk/components/libraries/util/sdk_errors.h:
../nrf52_sdk/components/softdevice/s140/headers/nrf_error.h:
../nrf52_sdk/components/libraries/util/app_util.h:
../nrf52_sdk/modules/nrfx/mdk/nrf.h:
../nrf52_sdk/modules/nrfx/mdk/nrf52840.h:
../nrf52_sdk/components/toolchain/cmsis/include/core_cm4.h:
../nrf52_sdk/components/toolchain/cmsis/include/cmsis_version.h:
../nrf52_sdk/components/toolchain/cmsis/include/cmsis_compiler.h:
../nrf52_sdk/components/toolchain/cmsis/include/cmsis_gcc.h:
../nrf52_sdk/components/toolchain/cmsis/include/mpu_armv7.h:
../nrf52_sdk/modules/nrfx/mdk/system_nrf52840.h:
../nrf52_sdk/modules/nrfx/mdk/nrf52840_bitfields.h:
../nrf52_sdk/modules/nrfx/mdk/nrf51_to_nrf52840.h:
../nrf52_sdk/modules/nrfx/mdk/nrf52_to_nrf52840.h:
../nrf52_sdk/modules/nrfx/mdk/compiler_abstraction.h:
../nrf52_sdk/components/softdevice/s140/headers/nrf52/nrf_mbr.h:
../nrf52_sdk/components/softdevice/s140/headers/nrf_svc.h:
../nrf52_sdk/components/libraries/util/sdk_macros.h:
../nrf52_sdk/components/libraries/util/nrf_assert.h:
../nrf52_sdk/components/libraries/util/app_util_platform.h:
../nrf52_sdk/components/softdevice/s140/headers/nrf_soc.h:
../nrf52_sdk/components/softdevice/s140/headers/nrf_svc.h:
../nrf52_sdk/components/softdevice/s140/headers/nrf_error.h:
../nrf52_sdk/components/softdevice/s140/headers/nrf_error_soc.h:
../nrf52_sdk/components/softdevice/s140/headers/nrf_nvic.h:
../nrf52_sdk/components/libraries/util/app_error.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/stdio.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/lib/gcc/arm-none-eabi/12.2.1/include/stdarg.h:
/usr/local/arm-gnu-toolchain-12.2.rel1-x86_64-arm-none-eabi/arm-none-eabi/include/sys/stdio.h:
../nrf52_sdk/components/libraries/util/app_error_weak.h:
../nrf52_sdk/components/softdevice/s140/headers/ble_gap.h:
../nrf52_sdk/components/softdevice/s140/headers/ble_hci.h:
../nrf52_sdk/components/softdevice/s140/headers/ble_ranges.h:
../nrf52_sdk/components/softdevice/s140/headers/ble_types.h:
../nrf52_sdk/components/softdevice/s140/headers/ble_err.h:
../nrf52_sdk/components/libraries/bootloader/dfu/nrf_dfu_req_handler.h:
../nrf52_sdk/components/libraries/bootloader/dfu/nrf_dfu_flash.h:
../nrf52_sdk/components/libraries/util/sdk_errors.h:
../nrf52_sdk/modules/nrfx/hal/nrf_power.h:
../nrf52_sdk/modules/nrfx/nrfx.h:
../nrf52_sdk/integration/nrfx/nrfx_config.h:
../nrf52_sdk/modules/nrfx/drivers/nrfx_common.h:
../nrf52_sdk/modules/nrfx/mdk/nrf_peripherals.h:
../nrf52_sdk/modules/nrfx/mdk/nrf52840_peripherals.h:
../nrf52_sdk/integration/nrfx/nrfx_glue.h:
../nrf52_sdk/integration/nrfx/legacy/apply_old_config.h:
../nrf52_sdk/modules/nrfx/soc/nrfx_irqs.h:
../nrf52_sdk/modules/nrfx/soc/nrfx_irqs_nrf52840.h:
../nrf52_sdk/components/libraries/util/nrf_assert.h:
../nrf52_sdk/components/libraries/util/app_util.h:
../nrf52_sdk/components/libraries/util/nordic_common.h:
../nrf52_sdk/modules/nrfx/soc/nrfx_coredep.h:
../nrf52_sdk/modules/nrfx/soc/nrfx_atomic.h:
../nrf52_sdk/components/libraries/util/sdk_resources.h:
../nrf52_sdk/components/softdevice/s140/headers/nrf_sd_def.h:
../nrf52_sdk/components/softdevice/s140/headers/nrf_soc.h:
../nrf52_sdk/modules/nrfx/drivers/nrfx_errors.h:
../nrf52_sdk/modules/nrfx/drivers/include/nrfx_power.h:
../nrf52_sdk/modules/nrfx/hal/nrf_power.h:
../nrf52_sdk/modules/nrfx/drivers/include/nrfx_power_clock.h:
../nrf52_sdk/components/libraries/delay/nrf_delay.h:
../nrf52_sdk/components/libraries/log/nrf_log.h:
../nrf52_sdk/components/libraries/experimental_section_vars/nrf_section.h:
../nrf52_sdk/components/libraries/log/src/nrf_log_internal.h:
../nrf52_sdk/components/libraries/log/nrf_log_instance.h:
../nrf52_sdk/components/libraries/log/nrf_log_types.h:
../nrf52_sdk/components/libraries/log/nrf_log_types.h:
../nrf52_sdk/components/libraries/log/nrf_log_ctrl.h:
../nrf52_sdk/components/libraries/log/src/nrf_log_ctrl_internal.h:
../nrf52_sdk/components/libraries/log/nrf_log_backend_interface.h:
../nrf52_sdk/components/libraries/bootloader/dfu/nrf_dfu_settings.h:
../nrf52_sdk/components/libraries/bootloader/dfu/nrf_dfu_utils.h:
../nrf52_sdk/components/libraries/bootloader/nrf_bootloader_wdt.h:
../nrf52_sdk/components/libraries/bootloader/nrf_bootloader_info.h:
../nrf52_sdk/components/softdevice/s140/headers/nrf_sdm.h:
../nrf52_sdk/components/softdevice/s140/headers/nrf_error_sdm.h:
../nrf52_sdk/components/libraries/bootloader/nrf_bootloader_app_start.h:
../nrf52_sdk/components/libraries/bootloader/nrf_bootloader_fw_activation.h:
../nrf52_sdk/components/libraries/bootloader/nrf_bootloader_dfu_timers.h:
../nrf52_sdk/components/libraries/scheduler/app_scheduler.h:
../nrf52_sdk/components/libraries/util/app_error.h:
../nrf52_sdk/components/libraries/bootloader/dfu/nrf_dfu_validation.h:
../nrf52_sdk/components/libraries/bootloader/dfu/dfu-cc.pb.h:
../nrf52_sdk/external/nano-pb/pb.h:
../nrf52_sdk/components/libraries/bootloader/dfu/nrf_dfu_handling_error.h:
../nrf52_sdk/modules/nrfx/hal/nrf_gpio.h:
../common/hw_connect.h:
../nrf52_sdk/modules/nrfx/hal/nrf_lpcomp.h:
../nrf52_sdk/modules/nrfx/hal/nrf_saadc.h:
../common/device_info.h:
