../objects/bootloader/oberon_backend_ecdsa.c.o: \
 ../nrf52_sdk/components/libraries/crypto/backend/oberon/oberon_backend_ecdsa.c \
 src/sdk_config.h src/app_config.h ../common/device_info.h \
 ../nrf52_sdk/components/libraries/util/nordic_common.h
src/sdk_config.h:
src/app_config.h:
../common/device_info.h:
../nrf52_sdk/components/libraries/util/nordic_common.h:
